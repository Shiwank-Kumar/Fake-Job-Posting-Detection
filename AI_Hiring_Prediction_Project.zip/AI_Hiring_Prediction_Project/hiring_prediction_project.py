"""
============================================================================
AI-Based Hiring Prediction System
============================================================================
A complete, worked Machine Learning project that predicts whether a
candidate will be Hired (1) or Rejected (0) based on resume features:
skills, experience, education, certifications, job role, salary
expectation, and project count.

Run this script top to bottom (e.g. `python hiring_prediction_project.py`)
or paste each STEP into its own Jupyter cell.

Author: Worked project generated with Claude
============================================================================
"""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report, RocCurveDisplay
)
import joblib

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 120
RANDOM_STATE = 42
CHART_DIR = "charts/"
MODEL_DIR = "models/"

# ============================================================================
# STEP 1: LOAD THE DATA
# ============================================================================
df = pd.read_csv("hiring_dataset.csv")
print("Dataset shape:", df.shape)
print(df.head())
print(df.info())

# ============================================================================
# STEP 2: DATA CLEANING
# ============================================================================
# 'Certifications' has missing values where a candidate holds none.
# We treat missing as the explicit category "None" rather than dropping rows.
df["Certifications"] = df["Certifications"].fillna("None")

# Sanity checks
print("\nMissing values after cleaning:\n", df.isnull().sum())
print("\nDuplicate rows:", df.duplicated().sum())
print("\nTarget distribution:\n", df["Recruiter Decision"].value_counts())
print("\nTarget distribution (%):\n",
      df["Recruiter Decision"].value_counts(normalize=True) * 100)

# Encode the target: Hire -> 1, Reject -> 0
df["Target"] = df["Recruiter Decision"].map({"Hire": 1, "Reject": 0})

# ============================================================================
# STEP 3: EXPLORATORY DATA ANALYSIS (EDA)
# ============================================================================

# 3.1 Target class balance
plt.figure(figsize=(5, 4))
ax = sns.countplot(x="Recruiter Decision", data=df, palette=["#2E7D32", "#C62828"],
                    order=["Hire", "Reject"])
for p in ax.patches:
    ax.annotate(f"{int(p.get_height())}", (p.get_x() + p.get_width() / 2, p.get_height()),
                ha="center", va="bottom", fontsize=10)
plt.title("Class Balance: Hire vs Reject")
plt.tight_layout()
plt.savefig(CHART_DIR + "01_target_balance.png")
plt.close()

# 3.2 Numeric feature distributions split by decision
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
for ax, col in zip(axes, ["Experience (Years)", "Projects Count", "Salary Expectation ($)"]):
    sns.boxplot(x="Recruiter Decision", y=col, data=df, ax=ax,
                order=["Hire", "Reject"], palette=["#2E7D32", "#C62828"])
    ax.set_title(col)
plt.tight_layout()
plt.savefig(CHART_DIR + "02_numeric_boxplots.png")
plt.close()

# 3.3 Hire rate by categorical features
fig, axes = plt.subplots(1, 3, figsize=(16, 4))
for ax, col in zip(axes, ["Education", "Job Role", "Certifications"]):
    rate = df.groupby(col)["Target"].mean().sort_values(ascending=False)
    sns.barplot(x=rate.index, y=rate.values, ax=ax, palette="Blues_d")
    ax.set_ylabel("Hire Rate")
    ax.set_title(f"Hire Rate by {col}")
    ax.set_ylim(0, 1)
    ax.tick_params(axis="x", rotation=30)
plt.tight_layout()
plt.savefig(CHART_DIR + "03_hire_rate_categorical.png")
plt.close()

# 3.4 Skill frequency and skill-level hire rate
all_skills = sorted(set(s for row in df["Skills"].str.split(", ") for s in row))
skill_hire_rate = {}
skill_count = {}
for skill in all_skills:
    mask = df["Skills"].str.contains(skill, regex=False)
    skill_hire_rate[skill] = df.loc[mask, "Target"].mean()
    skill_count[skill] = mask.sum()
skill_df = pd.DataFrame({"Skill": all_skills,
                          "Count": [skill_count[s] for s in all_skills],
                          "HireRate": [skill_hire_rate[s] for s in all_skills]}
                         ).sort_values("HireRate", ascending=False)

fig, ax1 = plt.subplots(figsize=(11, 5))
sns.barplot(x="Skill", y="HireRate", data=skill_df, palette="viridis", ax=ax1)
ax1.set_ylabel("Hire Rate")
ax1.set_title("Hire Rate by Skill (mentioned in resume)")
ax1.tick_params(axis="x", rotation=45)
plt.tight_layout()
plt.savefig(CHART_DIR + "04_skill_hire_rate.png")
plt.close()

# 3.5 Correlation heatmap of numeric features
numeric_cols = ["Experience (Years)", "Salary Expectation ($)", "Projects Count",
                "AI Score (0-100)", "Target"]
plt.figure(figsize=(6, 5))
sns.heatmap(df[numeric_cols].corr(), annot=True, cmap="coolwarm", center=0, fmt=".2f")
plt.title("Correlation Heatmap (Numeric Features)")
plt.tight_layout()
plt.savefig(CHART_DIR + "05_correlation_heatmap.png")
plt.close()

# 3.6 AI Score vs Decision -- reveals a DATA LEAKAGE issue (see report)
plt.figure(figsize=(6, 4))
sns.boxplot(x="Recruiter Decision", y="AI Score (0-100)", data=df,
            order=["Hire", "Reject"], palette=["#2E7D32", "#C62828"])
plt.title("AI Score (0-100) by Recruiter Decision")
plt.tight_layout()
plt.savefig(CHART_DIR + "06_ai_score_leakage.png")
plt.close()

hire_min = df.loc[df.Target == 1, "AI Score (0-100)"].min()
reject_max = df.loc[df.Target == 0, "AI Score (0-100)"].max()
print(f"\n[Leakage check] Min AI Score among Hires: {hire_min} | "
      f"Max AI Score among Rejects: {reject_max}")
print("--> The two classes are PERFECTLY separated by AI Score "
      "(no overlap). This column already encodes the answer, so it is "
      "excluded from the main model (see Step 4).")

# ============================================================================
# STEP 4: FEATURE ENGINEERING
# ============================================================================
# IMPORTANT MODELLING DECISION:
# 'AI Score (0-100)' is dropped from the primary feature set. EDA showed it
# perfectly separates Hire/Reject (min Hire score 65 vs max Reject score 60),
# meaning it is a proxy/derived version of the label itself rather than an
# independent resume attribute. Including it would let any model hit ~100%
# accuracy trivially, which teaches us nothing about real resume signal and
# would not generalise to a system that has to produce that score itself.
# We build the realistic model on the other 7 resume fields, and separately
# show the "leaky" model for comparison/teaching purposes only.

feature_df = df.copy()

# 4.1 Multi-hot encode the Skills column (each skill becomes a 0/1 column)
for skill in all_skills:
    feature_df[f"skill_{skill.replace(' ', '_')}"] = feature_df["Skills"].str.contains(
        skill, regex=False).astype(int)
feature_df["Skill_Count"] = feature_df[[c for c in feature_df.columns
                                         if c.startswith("skill_")]].sum(axis=1)

# 4.2 Certification flag + one-hot encode the category
feature_df["Has_Certification"] = (feature_df["Certifications"] != "None").astype(int)
feature_df = pd.get_dummies(feature_df, columns=["Certifications"], prefix="cert")

# 4.3 One-hot encode Education and Job Role
feature_df = pd.get_dummies(feature_df, columns=["Education", "Job Role"],
                             prefix=["edu", "role"])

# 4.4 Final feature matrix (drop identifiers, free text, target, and the leaky score)
drop_cols = ["Resume_ID", "Name", "Skills", "Recruiter Decision",
             "AI Score (0-100)", "Target"]
X = feature_df.drop(columns=drop_cols)
y = feature_df["Target"]

print(f"\nFinal feature matrix shape: {X.shape}")
print("Feature columns:", list(X.columns))

# ============================================================================
# STEP 5: TRAIN / TEST SPLIT
# ============================================================================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
)
print(f"\nTrain size: {X_train.shape[0]}  |  Test size: {X_test.shape[0]}")

# Scale numeric columns (helps Logistic Regression, SVM, KNN converge/behave well)
numeric_features = ["Experience (Years)", "Salary Expectation ($)",
                     "Projects Count", "Skill_Count"]
scaler = StandardScaler()
X_train_scaled = X_train.copy()
X_test_scaled = X_test.copy()
X_train_scaled[numeric_features] = scaler.fit_transform(X_train[numeric_features])
X_test_scaled[numeric_features] = scaler.transform(X_test[numeric_features])

# ============================================================================
# STEP 6: MODEL TRAINING -- COMPARE SEVERAL ALGORITHMS
# ============================================================================
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=7),
    "Decision Tree": DecisionTreeClassifier(max_depth=6, random_state=RANDOM_STATE),
    "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=8,
                                             random_state=RANDOM_STATE),
    "Gradient Boosting": GradientBoostingClassifier(random_state=RANDOM_STATE),
    "SVM (RBF)": SVC(probability=True, random_state=RANDOM_STATE),
}

results = []
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    preds = model.predict(X_test_scaled)
    proba = model.predict_proba(X_test_scaled)[:, 1]

    cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=cv, scoring="accuracy")

    results.append({
        "Model": name,
        "CV Accuracy (mean)": cv_scores.mean(),
        "CV Accuracy (std)": cv_scores.std(),
        "Test Accuracy": accuracy_score(y_test, preds),
        "Precision": precision_score(y_test, preds),
        "Recall": recall_score(y_test, preds),
        "F1 Score": f1_score(y_test, preds),
        "ROC-AUC": roc_auc_score(y_test, proba),
    })

results_df = pd.DataFrame(results).sort_values("F1 Score", ascending=False)
print("\n================ MODEL COMPARISON (resume features only) ================")
print(results_df.to_string(index=False))
results_df.to_csv("model_comparison_results.csv", index=False)

# 6.1 Visualize model comparison
plt.figure(figsize=(9, 5))
plot_df = results_df.melt(id_vars="Model",
                           value_vars=["Test Accuracy", "Precision", "Recall", "F1 Score"],
                           var_name="Metric", value_name="Score")
sns.barplot(x="Model", y="Score", hue="Metric", data=plot_df)
plt.title("Model Comparison Across Metrics (Resume-Only Features)")
plt.ylim(0, 1.05)
plt.xticks(rotation=20)
plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
plt.tight_layout()
plt.savefig(CHART_DIR + "07_model_comparison.png")
plt.close()

# ============================================================================
# STEP 7: DEEP-DIVE ON THE BEST MODEL (Random Forest)
# ============================================================================
best_model_name = results_df.iloc[0]["Model"]
best_model = models[best_model_name]
print(f"\nBest model by F1 score: {best_model_name}")

y_pred_best = best_model.predict(X_test_scaled)
print("\nClassification Report (best model):\n",
      classification_report(y_test, y_pred_best, target_names=["Reject", "Hire"]))

# 7.1 Confusion matrix
cm = confusion_matrix(y_test, y_pred_best)
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Reject", "Hire"], yticklabels=["Reject", "Hire"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title(f"Confusion Matrix - {best_model_name}")
plt.tight_layout()
plt.savefig(CHART_DIR + "08_confusion_matrix.png")
plt.close()

# 7.2 ROC curves for all models (test set)
plt.figure(figsize=(7, 6))
for name, model in models.items():
    RocCurveDisplay.from_estimator(model, X_test_scaled, y_test, ax=plt.gca(), name=name)
plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Chance")
plt.title("ROC Curves - All Models (Resume-Only Features)")
plt.tight_layout()
plt.savefig(CHART_DIR + "09_roc_curves.png")
plt.close()

# 7.3 Feature importance (Random Forest)
rf_model = models["Random Forest"]
importances = pd.Series(rf_model.feature_importances_, index=X.columns) \
    .sort_values(ascending=False).head(15)
plt.figure(figsize=(8, 6))
sns.barplot(x=importances.values, y=importances.index, palette="mako")
plt.title("Top 15 Feature Importances (Random Forest)")
plt.xlabel("Importance")
plt.ylabel("Feature")
plt.tight_layout()
plt.savefig(CHART_DIR + "10_feature_importance.png")
plt.close()
print("\nTop 10 most important features:\n", importances.head(10))

# ============================================================================
# STEP 8: THE "LEAKY" MODEL -- WHAT HAPPENS IF WE KEEP AI SCORE?
#         (included purely to demonstrate the data-leakage concept)
# ============================================================================
X_leak = X.copy()
X_leak["AI Score (0-100)"] = feature_df["AI Score (0-100)"]
X_train_l, X_test_l, y_train_l, y_test_l = train_test_split(
    X_leak, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
)
leaky_model = RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE)
leaky_model.fit(X_train_l, y_train_l)
leak_preds = leaky_model.predict(X_test_l)
print(f"\n[Leaky model] Random Forest WITH 'AI Score' included -> "
      f"Test Accuracy = {accuracy_score(y_test_l, leak_preds):.4f}, "
      f"F1 = {f1_score(y_test_l, leak_preds):.4f}")
print("This near-perfect score is an artifact of label leakage, not genuine "
      "predictive skill -- see the project report for discussion.")

# ============================================================================
# STEP 9: SAVE THE FINAL MODEL FOR REUSE
# ============================================================================
joblib.dump(best_model, MODEL_DIR + "best_hiring_model.pkl")
joblib.dump(scaler, MODEL_DIR + "feature_scaler.pkl")
joblib.dump(list(X.columns), MODEL_DIR + "feature_columns.pkl")
print(f"\nSaved best model ({best_model_name}) and preprocessing objects to '{MODEL_DIR}'")

# ============================================================================
# STEP 10: SIMPLE PREDICTION FUNCTION FOR A NEW CANDIDATE
# ============================================================================
def predict_new_candidate(candidate: dict) -> str:
    """
    candidate: dict with keys matching the raw dataset columns, e.g.
    {
        "Skills": "Python, Machine Learning, SQL",
        "Experience (Years)": 4,
        "Education": "B.Tech",
        "Certifications": "AWS Certified",   # or "None"
        "Job Role": "Data Scientist",
        "Salary Expectation ($)": 75000,
        "Projects Count": 5
    }
    Returns "Hire" or "Reject".
    """
    row = {col: 0 for col in X.columns}
    row["Experience (Years)"] = candidate["Experience (Years)"]
    row["Salary Expectation ($)"] = candidate["Salary Expectation ($)"]
    row["Projects Count"] = candidate["Projects Count"]

    cand_skills = [s.strip() for s in candidate["Skills"].split(",")]
    skill_cnt = 0
    for skill in all_skills:
        col = f"skill_{skill.replace(' ', '_')}"
        if col in row and skill in cand_skills:
            row[col] = 1
            skill_cnt += 1
    row["Skill_Count"] = skill_cnt

    row["Has_Certification"] = 0 if candidate["Certifications"] == "None" else 1
    cert_col = f"cert_{candidate['Certifications']}"
    if cert_col in row:
        row[cert_col] = 1

    edu_col = f"edu_{candidate['Education']}"
    if edu_col in row:
        row[edu_col] = 1
    role_col = f"role_{candidate['Job Role']}"
    if role_col in row:
        row[role_col] = 1

    X_new = pd.DataFrame([row])[X.columns]
    X_new[numeric_features] = scaler.transform(X_new[numeric_features])
    pred = best_model.predict(X_new)[0]
    return "Hire" if pred == 1 else "Reject"


# Example usage:
example_candidate = {
    "Skills": "Python, Machine Learning, SQL",
    "Experience (Years)": 6,
    "Education": "B.Tech",
    "Certifications": "AWS Certified",
    "Job Role": "Data Scientist",
    "Salary Expectation ($)": 85000,
    "Projects Count": 7,
}
print(f"\nExample new-candidate prediction: {predict_new_candidate(example_candidate)}")

print("\n=== PROJECT PIPELINE COMPLETE ===")
print("Charts saved to:", CHART_DIR)
print("Model artifacts saved to:", MODEL_DIR)
print("Comparison table saved to: model_comparison_results.csv")
